<?if(!defined("site_root")){exit();}?>



<?
echo($profile_footer);
?>