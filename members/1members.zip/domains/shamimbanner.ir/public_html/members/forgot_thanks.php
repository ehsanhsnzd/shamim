<?$site="forgot";?>
<?include("../admin/function/db.php");?>
<?include("../inc/header.php");?>

<h1><?=word_lang("forgot password")?>:</h1>



<p><?=word_lang("password sent")?></p>


<?include("../inc/footer.php");?>